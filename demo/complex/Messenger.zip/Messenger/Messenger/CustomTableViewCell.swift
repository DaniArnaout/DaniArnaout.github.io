//
//  CustomTableViewCell.swift
//  Complex
//
//  Created by Dani Arnaout on 10/4/17.
//  Copyright © 2017 Abstract Layer. All rights reserved.
//

import UIKit
import AbstractLayer

class CustomTableViewCell: UITableViewCell {

  @IBOutlet weak var dateLabel: ALDateLabel!
}
