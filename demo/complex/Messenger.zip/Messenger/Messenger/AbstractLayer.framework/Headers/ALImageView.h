//
//  ALImageView.h
//  AbstractLayer
//
//  Created by Dani Arnaout on 5/2/17.
//  Copyright © 2017 AbstractLayer, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 `ALImageViewLoadingDelegate` is a protocol that provides method for loading status of image view so you can do your custom UI work.
 */
@protocol ALImageViewLoadingDelegate <NSObject>

@optional
/**
 Implement this protocol to do custom work when the image view is about to load.
 
 @param imageView The image view that will load
 */
- (void)willLoadImageView:(UIImageView *)imageView;

/**
 Implement this protocol to do custom work as soon as the image view loads.
 
 @param imageView The image view that has just loaded
 @param error Any error that was caused during loading the image like wrong URL or image doesn't exist in bundle.
 */
- (void)didLoadImageView:(UIImageView *)imageView error:(NSError *)error;

@end

/**
 `ALImageView` is a subclass of `UIImageView` with convenience properties to help display images fetched from a JSON document.
 
 ## Image Downloading
 AbstractLayer handles images download without you worrying about what's going on behind the scenes. If the value of `jsonKey` is a URL, then the image will be downloaded and displayed as soon as its fully downloaded.
 
 ## Image Caching
 AbstractLayer caches images on your behalf both in memory and on disk.
 AbstractLayers handles caches expiry dates, it also ensures no single URL is downloaded more than once. Cache options will be available in next releases.
 */
@interface ALImageView : UIImageView

/**
 The JSON key that represents the value from the JSON document that represents the image to be displayed.
 
 Use this property to apply auto-data-binding between a JSON key and an image view.
 There are three different types of values that AbstractLayer expects in thsi process:
 1. URL (A full URL that points to an image. Preferably ending with an extension)
 2. A string (In this case, AbstractLayer will look into your app's Assets folder to match an image with the same name)
 3. A boolean (In this case, you'll have to set the image from your Assets folder. If the value is false, then the image will be hidden, otherwise, it'll be shown) 
  Ex: Verified badge in your profile.
 
 Supported image formats are: PNG, JPG, JPEG.
 Later support for GIF.
 */
@property (nonatomic, copy) IBInspectable NSString *jsonKey;

/**
 Display an optional placeholder image while the image gets downloaded and displayed.
 
 */
@property (nonatomic, strong) IBInspectable UIImage *placeholder;

/**
 Determines whether to cache the image on disk after downloading it for the first time.
 
 Default is YES
 */
@property (nonatomic, assign) IBInspectable BOOL diskCache;

/**
 Determines the image cache deleting policy like Least Frequently Used.
 Supported: (LRU, LFU, FIFO, LIFO)
 
 Default is LRU
 */
@property (nonatomic, copy) IBInspectable NSString *cachePolicy;

/**
 The delegate of ALImageView
 
 Conform to this delegate to implement optional methods for image will & did load
*/
@property (nonatomic, strong) id<ALImageViewLoadingDelegate> delegate;

/**
 Override this method in your subclass to do custom work when the image view is about to load.
 */
- (void)willLoadImage;

/**
 Override this method in your subclass to do custom work as soon as the image view loads.
 
 @param error Any error that was caused during loading the image like wrong URL or image doesn't exist in bundle.
 */
- (void)didLoadImageWithError:(NSError *)error;

@end
