//
//  Message.swift
//  Messenger
//
//  Created by Dani Arnaout on 11/2/17.
//  Copyright © 2017 Abstract Layer. All rights reserved.
//

import UIKit

@objcMembers
class Message: NSObject {
  var id: String?
  var name: String?
  var lastMessage: String?
  var timestamp: NSNumber?
}
