//
//  UIImageView+Inspectable.h
//  AbstractLayer
//
//  Created by Dani Arnaout on 4/25/17.
//  Copyright © 2017 AbstractLayer, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 
 Inspectable is a public category on UIImageView with convenience properties to help adjust the looks of the image view all the way from a cornder radius to a complete circual look.
 */
@interface UIImageView (Inspectable)

/**
 Turn on if you want the image view to become circular
 
 AbstractLayer will set the corner radius to half the width of the image view to achieve a ciruclar image
 
 Default is NO.
 */
@property (nonatomic, assign) IBInspectable BOOL circular;

/**
 Set this to any value above 0 to give your image view a corner radius
 
 Default is 0.
 */
@property (nonatomic, assign) IBInspectable NSUInteger cornerRadius;

@end
