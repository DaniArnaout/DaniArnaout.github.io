//
//  CustomTableViewCell.swift
//  Silicon Valley
//
//  Created by Dani Arnaout on 8/31/17.
//  Copyright © 2017 Abstract Layer. All rights reserved.
//

import UIKit
import AbstractLayer

class CustomTableViewCell: UITableViewCell {
    
  @IBOutlet weak var dateLabel: ALDateLabel!
}
