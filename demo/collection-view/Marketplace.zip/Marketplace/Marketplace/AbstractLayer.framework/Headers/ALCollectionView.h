//
//  ALCollectionView.h
//  AbstractLayer
//
//  Created by Dani Arnaout on 7/22/17.
//  Copyright © 2017 AbstractLayer, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ALCollectionViewLoadingDelegate <NSObject>
@optional
/**
 Override this method in your subclass to do custom work when the table view is about to load. This also includes when the user pulls the table to refresh.
 */
- (void)willLoadCollectionView;

/**
 Override this method in your subclass to do custom work as soon as the table loads. This also works when pagination is enabled and new content is added.
 
 @param error Any error that was caused during loading the table from sending the request, receiving response, parsing, and data-binding.
 */
- (void)didLoadCollectionViewWithError:(NSError *)error;

@end

@protocol ALCollectionViewSizingDelegate <NSObject>
@optional
/**
 Implement this method only if you're using Dynamic Height. Width will be automatically calculated by setting Columns property
 
 @param collectionView The collection view object
 @param indexPath The index path of item being displayed
 @param item A dictionary with all JSON keys/values
 */
- (CGFloat)collectionView:(UICollectionView *)collectionView heightForItemAtIndexPath:(NSIndexPath *)indexPath itemInfo:(NSDictionary *)item;

/**
 Implement this method if you wish to achieve different line spacing for different devices or orientations.
 
 @param device Current user device
 @param orientation Current device orientation
 */
- (CGFloat)lineSpacingForDevice:(UIUserInterfaceIdiom)device orientation:(UIDeviceOrientation)orientation;

/**
 Implement this method if you wish to achieve different inter-item spacing for different devices or orientations.
 
 @param device Current user device
 @param orientation Current device orientation
 */
- (CGFloat)interitemSpacingForDevice:(UIUserInterfaceIdiom)device orientation:(UIDeviceOrientation)orientation;

/**
 Implement this method if you wish to achieve different inset spacing for different devices or orientations.
 
 @param device Current user device
 @param orientation Current device orientation
 */
- (UIEdgeInsets)insetForForDevice:(UIUserInterfaceIdiom)device orientation:(UIDeviceOrientation)orientation;
@end

/**
 `ALTableViewController` is a subclass of `UITableViewController` with convenience properties for making HTTP requests. A `url` must be provided to successfully make a request out of the box.
 ## Subclassing Notes
 Developers targeting iOS 9 or later that deal extensively with a web service are encouraged to use `ALTableViewController` without the need to subclass it.
 In case you need to alter any of UITableViewController's delegate methods, feel free to subclass `ALTableViewController` and implement your own methods.
 ## Methods to Override
 To change the behavior of all data task operation construction, override `UITableViewController` regular delegate and datasource methods like:  `tableView:tableView cellForRowAtIndexPath:indexPath;`.
 */
@interface ALCollectionView : UICollectionView

@property (nonatomic, strong) id <ALCollectionViewLoadingDelegate> loadingDelegate;
@property (nonatomic, strong) id <ALCollectionViewSizingDelegate> sizingDelegate;
/**
 Determines the number of columns in the Collection View
 
 Set this to the number of columns you wish to see. Just design your cell and AbstractLayer will auto-resize your cells for different screens preserving the cell ratio, inter-item spacing, line spacing, and section insets.  Default is 0, which means that AbstractLayer will not handle resizing for you
 */
@property (nonatomic, assign) IBInspectable NSUInteger columns;

/**
 Turn on if the items have different heights according to content
 
 Set this to YES if you want to acheive a Pinterest-like Collection View where items have different heights.
 If set to YES, you MUST implement
 - (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
 
 Default is NO.
 */
@property (nonatomic, assign) IBInspectable BOOL customHeight;

/**
 The API URL that points to a JSON document.
 
 Use this property to point to a URL that will get parsed and stored in `ALDynamicObject` for
 @warning Make sure the URL is a secured https, otherwise you'll have to set your App Transport Layer from your info.plist
 */
@property (nonatomic, copy) IBInspectable NSString * url;

/**
 The HTTP method for the request built using a supplied `url`.
 
 Use this property to set the HTTP method. Available methods are "GET" "POST" "PUT" "DELETE"
 Default value is "GET"
 */
@property (nonatomic, copy) IBInspectable NSString * httpMethod;

/**
 The API request header
 
 Use this property to construct your request header. If you want to use any of the sotred values, use double braces. Example: {{auth_key}}
 Default value is empty
 */

@property (nonatomic, copy) IBInspectable NSString * header;

/**
 The API request body parameters
 
 Use this property to construct your request body.
 If you want to use any of the sotred values, use double braces. Example: {{auth_key}}
 Default value is empty
 */
@property (nonatomic, copy) IBInspectable NSString * body;

/**
 The root of the JSON array
 
 Use this property to point to the root of your JSON array to parse. Use dot notation to traverse through more level. Example: (data.results.users)
 Default value is empty string
 */
@property (nonatomic, copy) IBInspectable NSString * jsonRoot;

/**
 The cell identifier
 
 Use this property to point to the cell identifier you set in storyboard. Example: (cell)
 If you have multiple sections, use a comma separated cell identifier value. Example (cell1,cell2)
 Default value is "cell"
 */
@property (nonatomic, copy) IBInspectable NSString *cellIdentifier;

/**
 Set if pagination is enabled
 
 If you're paginating data, set this parameter to YES, and it will automatically do the pagination */
@property (nonatomic, assign) IBInspectable BOOL pagination;

/**
 The parameter used to set page number
 
 If you're paginating data, set this parameter with the page number parameter. By default this is usually called 'page'
 */
@property (nonatomic, copy) IBInspectable NSString * pageParam;

/**
 The name of your cell XIB file
 
 Set this property only if you're using XIB instead of storyboard prototype cells
 */
@property (nonatomic, copy) IBInspectable NSString * xib;

/**
 Determines if table should show a loader before loading content
 
 Set this property to YES if you want to add a default `UIActivityIndicator` on top of your table.
 Default value is `NO`
 */
@property (nonatomic, assign) IBInspectable BOOL loader;

/**
 Determines the color of the loader view
 
 Set this property to tint your loader with a color.
 Default value is `[UIColor whiteColor]`
 */
@property (nonatomic, strong) IBInspectable UIColor * loaderColor;

/**
 Determines if table should refresh its content when pulled off screen
 
 Set this property to YES if you want to add a default `UIRefreshControl` on top of your table.
 Default value is `NO`
 */
@property (nonatomic, assign) IBInspectable BOOL pullToRefresh;

/**
 Determines if collection should display cached result in network isn't reachable
 
 Set this property to YES if you want users to see results even if they're offline.
 Default value is `NO`
 */
@property (nonatomic, assign) IBInspectable BOOL offlineBrowse;

/**
 Authentication type
 
 If your API has authentication, then you must specify the type of authentication. Current available type is JWT
 */
@property (nonatomic, copy) IBInspectable NSString * authType;

/**
 Authentication keys
 
 If your API has authentication, then you must specify the keys like JWT secret. Example secret={{secret}}. It's always recommended to pass secret keys as dynamic parameters for security reasons.
 */
@property (nonatomic, copy) IBInspectable NSString * authKeys;

@property (nonatomic, assign) IBInspectable NSInteger iPadPortrait;
@property (nonatomic, assign) IBInspectable NSInteger iPadLandscape;
@property (nonatomic, assign) IBInspectable NSInteger iPhoneLandscape;

/**
 The raw response data retrieved from the API call
 
 Once the API returns a response, this property is set to hold the value of the response data
 Default value is nil
 */
@property (nonatomic, strong, readonly) NSData *responseData;

/**
 The array of objects retrieved from the API call
 
 You can access the array of objects (NSDictionary) that represents the API response. Use this to pass data between view controllers
 Default value is empty dictionary
 */
@property (nonatomic, copy, readonly) NSArray * array;

/**
 Resends the reqeust to the server and parses the new response disregarding cache options. Used when a parameter is changed and you want to invoke a reload method.
 */
- (void)forceReloadData;

- (NSInteger)numberOfSections;
- (NSInteger)numberOfItemsInSection:(NSInteger)section;
- (UICollectionViewCell *)cellForItemAtIndexPath:(NSIndexPath *)indexPath;
- (CGSize)sizeForItemAtIndexPath:(NSIndexPath *)indexPath;
- (void) moveItemAtIndexPath:(NSIndexPath *)indexPath toIndexPath:(NSIndexPath *)newIndexPath;

@end
