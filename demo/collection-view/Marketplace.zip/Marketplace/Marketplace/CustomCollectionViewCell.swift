//
//  CustomCollectionViewCell.swift
//  Marketplace
//
//  Created by Dani Arnaout on 8/31/17.
//  Copyright © 2017 Abstract Layer. All rights reserved.
//

import UIKit
import AbstractLayer

class CustomCollectionViewCell: UICollectionViewCell {
    
  @IBOutlet weak var priceLabel: ALLabel!
}
