//
//  CollectionViewController.swift
//  Marketplace
//
//  Created by Dani Arnaout on 8/31/17.
//  Copyright © 2017 Abstract Layer. All rights reserved.
//

import UIKit
import AbstractLayer

class CollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
  
  override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let collection = collectionView as! ALCollectionView
    let cell = collection.cellForItem(at: indexPath) as! CustomCollectionViewCell // Get cell
    
    let item = collection.array[indexPath.row] as! [String:Any] // Get item dictionary
    var price = Float(item["price"] as! String) // Price in USD
    price = price! * 0.85 // Convert to EUR
    cell.priceLabel?.text = "€" + String(describing: price!) // Set new value
    return cell
  }
  
  override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return collectionView.numberOfItems(inSection: section)
  }
  
  func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
    let collection = collectionView as! ALCollectionView
    return collection.sizeForItem(at: indexPath)
  }
}
