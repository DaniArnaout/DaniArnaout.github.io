//
//  ALLabel.h
//  AbstractLayer
//
//  Created by Dani Arnaout on 5/2/17.
//  Copyright © 2017 AbstractLayer, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 `ALLabel` is a subclass of `UILabel` with convenience properties to help parse and edit outcomes visually. A `jsonKey` must be provided to successfully and dynamically do databinding within a `ALTableViewController`.
 ## Subclassing Notes
 Feel free to sublcass `ALLabel` and introduce your own customization, as this class just adds few properties on top of the native `UILabel` class provided by Apple.
 */
@interface ALLabel : UILabel

/**
 The JSON key that represents the value from the JSON document that needs to be reflected in this label.

 Use this property to apply auto-data-binding between a JSON key and the label text.
 The label text will be set to an empty string if this property was kept empty, of if the key wasn't found in the JSON document.
*/
@property (nonatomic, copy) IBInspectable NSString *jsonKey;

/**
 The string that needs to proceed the value parsed from the JSON document.
 
 Use this property if you wish to add a string just before the value you retrieved for the label. Ex: If your `jsonKey` returns a number of comments for a certain article, then the label will display the number solely. But, if you want to display it as "Comments: 3", then set this property to "Comments: ".
 Default value is empty string.
 */
@property (nonatomic, copy) IBInspectable NSString *prefix;

/**
 The string that needs to succeed the value parsed from the JSON document.
 
 Use this property if you wish to add a string to the end of the value you retrieved for the label. Ex: If your `jsonKey` returns a number of likes for a certain article, then the label will display the number solely. But, if you want to display it as "1 like", then set this property to "like".
 Default value is empty string.
 */
@property (nonatomic, copy) IBInspectable NSString *suffix;

/**
 Determines if you need to handle singular/plural words in a label.
 
 Use this property along with either prefix or suffix.
 Ex: If your `jsonKey` returns a number of likes for a certain article, then the label will display the number solely. But, if you want to display it as "1 like" & "3 likes" in the plural form, then set this property to YES. AbstractLayer will automatically refer to its dictionary and get the plural form of a word if the count is 0 or more than 1.
 Default value is NO.
 */
@property (nonatomic, assign) IBInspectable BOOL pluralize;

@end
