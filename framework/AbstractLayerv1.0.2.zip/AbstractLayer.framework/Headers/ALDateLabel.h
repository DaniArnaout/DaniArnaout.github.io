//
//  ALDateLabel.h
//  AbstractLayer
//
//  Created by Dani Arnaout on 4/28/17.
//  Copyright © 2017 AbstractLayer, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ALLabel.h"

/**
 `ALDateLabel` is a subclass of `ALLabel` with convenience properties to help display dates parsed from timestamps in any desired format complying with `UIDateFormatter` standards. */
@interface ALDateLabel : ALLabel

/**
 The date format of the date received from JSON response according to the standard `UIDateFormatter`
 
 Use this property if you wish to format your JSOn date into one of the available `UIDateFormatter` formats.
 Ex: "yyyy-MM-dd HH:mm a"
 Ex: "EEE MMM dd HH:mm:ss ZZZ yyyy"
 Default value is EPOC timestamp.
 */
@property (nonatomic, copy) IBInspectable NSString *inputFormat;

/**
 The date format of the label you want to dispaly according to the standard `UIDateFormatter`
 
 Use this property if you wish to format your label into one of the available `UIDateFormatter` formats.
 Ex: "yyyy-MM-dd HH:mm a"
 Ex: "EEE MMM dd HH:mm:ss ZZZ yyyy"
 Default value is "EEE MMM dd HH:mm:ss ZZZ yyyy".
 */
@property (nonatomic, copy) IBInspectable NSString *outputFormat;

/**
 Represents the date that the label is displaying
 */
@property (nonatomic, copy) IBInspectable NSDate *date;

@end
