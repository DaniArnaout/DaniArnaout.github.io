//
//  ALStore.h
//  AbstractLayer
//
//  Created by Dani Arnaout on 7/7/17.
//  Copyright © 2017 AbstractLayer, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 `ALStore` has convenience methods to store key/value pairs to be used as a parameter in interface builder. Mostly used with `ALTableViewController`.
 */
@interface ALStore : NSObject

/**
 Get the shared instance of ALStore
 */
+ (instancetype)sharedInstance;

/**
 Call this method to set the key/value pair to be stored locally.
 
 @param value The value of the key to set, any Foundation subclass is accepted.
 @param key The key to store the value locally.
 */
- (void)setValue:(id)value forKey:(NSString *)key;

/**
 Call this method to get the value of a key stored locally via AbstractLayer.
 
 @param key The key that was used to stored a local value
 */
- (id)valueForKey:(NSString *)key;

@end
